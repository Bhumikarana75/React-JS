import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { deleteMovie, loadMovies } from "../redux/action/movieAction";
import { useNavigate } from "react-router-dom";

const ViewMovies = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { movies } = useSelector((state) => state.movie);

  useEffect(() => {
    dispatch(loadMovies());
  }, [dispatch]);

  const handleDelete = (id) => {
    if (window.confirm("Are you sure?")) {
      dispatch(deleteMovie(id));
    }
  };

  const handleEdit = (id) => {
    navigate(`/edit/${id}`);
  };

  return (
    <div className="container mt-4">
      <h3 className="text-center text-info mb-4">🎞️ All Movies</h3>

      <table className="table table-bordered table-striped table-hover">
        <thead className="table-dark">
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Genres</th>
            <th>Rating</th>
            <th>Poster</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {movies.map((m) => (
            <tr key={m.id}>
              <td>{m.id}</td>
              <td>{m.title}</td>
              <td>{m.genre_ids.join(", ")}</td>
              <td>{m.vote_average}</td>
              <td>
                <img src={m.poster_path} alt={m.title} style={{ width: "60px" }} />
              </td>
              <td>
                <button className="btn btn-warning btn-sm me-2" onClick={() => handleEdit(m.id)}>✏️ Edit</button>
                <button className="btn btn-danger btn-sm" onClick={() => handleDelete(m.id)}>🗑 Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ViewMovies;
