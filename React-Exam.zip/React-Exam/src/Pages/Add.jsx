import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { addMovie } from "../redux/action/movieAction";

const AddMovie = () => {
  const dispatch = useDispatch();
  const [form, setForm] = useState({
    title: "",
    genre_ids: "",
    vote_average: "",
    poster_path: ""
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleAdd = () => {
    if (!form.title || !form.genre_ids || !form.vote_average || !form.poster_path) {
      return alert("Please fill all fields.");
    }

    const newMovie = {
      ...form,
      genre_ids: form.genre_ids.split(",").map((id) => Number(id.trim())),
      vote_average: parseFloat(form.vote_average)
    };

    dispatch(addMovie(newMovie));
    alert("Movie added!");
    setForm({ title: "", genre_ids: "", vote_average: "", poster_path: "" });
  };

  return (
    <div className="container mt-3 col-md-8">
      <h3 className="text-center mb-4 text-primary">🎬 Add Movie</h3>

      <div className="form-group mb-3">
        <label>Title</label>
        <input type="text" name="title" className="form-control" value={form.title} onChange={handleChange} />
      </div>

      <div className="form-group mb-3">
        <label>Genre IDs (comma separated)</label>
        <input type="text" name="genre_ids" className="form-control" value={form.genre_ids} onChange={handleChange} />
      </div>

      <div className="form-group mb-3">
        <label>Rating</label>
        <input type="number" name="vote_average" className="form-control" value={form.vote_average} onChange={handleChange} />
      </div>

      <div className="form-group mb-3">
        <label>Poster Path</label>
        <input type="text" name="poster_path" className="form-control" value={form.poster_path} onChange={handleChange} />
      </div>

      <button className="btn btn-success w-100" onClick={handleAdd}>Add Movie</button>
    </div>
  );
};

export default AddMovie;
