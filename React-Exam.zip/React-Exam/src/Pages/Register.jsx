import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

function SignUp({ setUserList, userList }) {
  const [newUsername, setNewUsername] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const navigate = useNavigate();

  const handleCreateAccount = () => {
    if (!newUsername || !newPassword || !newEmail) {
      alert("Please fill in all fields.");
      return;
    }

    const trimmedUsername = newUsername.trim().toLowerCase();
    const trimmedEmail = newEmail.trim().toLowerCase();

    const existingUser = userList.find(
      (user) => user.username.toLowerCase() === trimmedUsername || user.email.toLowerCase() === trimmedEmail
    );

    if (existingUser) {
      alert("User with this username or email already exists.");
      return;
    }

    const newUser = {
      username: trimmedUsername,
      password: newPassword,
      email: trimmedEmail,
      name: trimmedUsername,
    };

    const updatedUserList = [...userList, newUser];
    setUserList(updatedUserList);
    localStorage.setItem("userList", JSON.stringify(updatedUserList));

    alert("✅ Account created successfully! You can now login.");
    navigate("/");
  };

  return (
    <div className="container d-flex justify-content-center align-items-center vh-100">
      <div className="card p-4 shadow rounded" style={{ maxWidth: "400px", width: "100%" }}>
        <h4 className="mb-3 text-center text-success">Register</h4>
        <input
          type="text"
          className="form-control mb-3"
          placeholder="Username"
          value={newUsername}
          onChange={(e) => setNewUsername(e.target.value)}
        />
        <input
          type="email"
          className="form-control mb-3"
          placeholder="Email"
          value={newEmail}
          onChange={(e) => setNewEmail(e.target.value)}
        />
        <input
          type="password"
          className="form-control mb-3"
          placeholder="Password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
        />
        <button className="btn btn-primary w-100" onClick={handleCreateAccount}>
          Sign Up
        </button>
      </div>
    </div>
  );
}

export default SignUp;
