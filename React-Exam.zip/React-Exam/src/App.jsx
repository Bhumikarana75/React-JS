import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import SignUp from "./Pages/Register";
import SignIn from "./Pages/Login";
import Navbar from "./component/Navbar";
import ViewMovies from "./Pages/View";
import AddMovie from "./Pages/Add";
import EditMovie from "./Pages/Edit";

function App() {
  const [userList, setUserList] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    // Load login status
    const loggedInStatus = localStorage.getItem("isLoggedIn");
    setIsLoggedIn(loggedInStatus === "true");

    // Load user list from localStorage
    const users = JSON.parse(localStorage.getItem("userList")) || [];
    setUserList(users);
  }, []);

  return (
    <Router>
      <Navbar isLoggedIn={isLoggedIn} setIsLoggedIn={setIsLoggedIn} />

      <Routes>
        <Route
          path="/"
          element={
            <SignIn userList={userList} setIsLoggedIn={setIsLoggedIn} />
          }
        />
        <Route
          path="/signup"
          element={
            <SignUp setUserList={setUserList} userList={userList} />
          }
        />
        <Route
          path="/add"
          element={isLoggedIn ? <AddMovie /> : <SignIn userList={userList} setIsLoggedIn={setIsLoggedIn} />}
        />
        <Route
          path="/view"
          element={isLoggedIn ? <ViewMovies /> : <SignIn userList={userList} setIsLoggedIn={setIsLoggedIn} />}
        />
        <Route
          path="/edit/:id"
          element={isLoggedIn ? <EditMovie /> : <SignIn userList={userList} setIsLoggedIn={setIsLoggedIn} />}
        />

        {/* 404 Route */}
        <Route path="*" element={<h2 className="text-center mt-5 text-danger">404 - Page Not Found</h2>} />
      </Routes>
    </Router>
  );
}

export default App;
