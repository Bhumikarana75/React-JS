export const addMovie = (movie) => (dispatch, getState) => {
  dispatch({ type: "ADD_MOVIE", payload: movie });
  localStorage.setItem("movies", JSON.stringify(getState().movie.movies));
};

export const deleteMovie = (id) => (dispatch, getState) => {
  dispatch({ type: "DELETE_MOVIE", payload: id });
  localStorage.setItem("movies", JSON.stringify(getState().movie.movies));
};

export const updateMovie = (updatedMovie) => (dispatch, getState) => {
  dispatch({ type: "UPDATE_MOVIE", payload: updatedMovie });
  localStorage.setItem("movies", JSON.stringify(getState().movie.movies));
};

export const loadMovies = () => (dispatch) => {
  const movies = JSON.parse(localStorage.getItem("movies")) || [];
  dispatch({ type: "LOAD_MOVIES", payload: movies });
};
