const initialState = {
  movies: [],
};

const movieReducer = (state = initialState, action) => {
  switch (action.type) {
    case "LOAD_MOVIES":
      return { ...state, movies: action.payload };

    case "ADD_MOVIE":
      return {
        ...state,
        movies: [...state.movies, { ...action.payload, id: Date.now() }],
      };

    case "DELETE_MOVIE":
      return {
        ...state,
        movies: state.movies.filter((m) => m.id !== action.payload),
      };

    case "UPDATE_MOVIE":
      return {
        ...state,
        movies: state.movies.map((m) =>
          m.id === action.payload.id ? action.payload : m
        ),
      };

    default:
      return state;
  }
};

export default movieReducer;
